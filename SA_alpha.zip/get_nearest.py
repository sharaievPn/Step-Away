"""
Additional module to script.py
Calculates the nearest lcoation
"""


from haversine import haversine


def get_nearest(path: str, latitude: float, longitude: float) -> list:
    """
    The function do something
    """
    res = []
    with open(path, 'r', encoding='utf-8') as file_:
        file_ = file_.read().replace('\t', ' ')
        file_ = file_.split('\n')[1:]
        for row in file_:
            data = row.split(',')
            try:
                distance = haversine((latitude, longitude), (float(data[2]), float(data[3])))
            except IndexError:
                continue
            res.append([row, distance])

    res = sorted(res, key=lambda distance: distance[1])
    # print(distance)
    return res[:5]

print(get_nearest('files/shelters_cor.csv', 49, 49))